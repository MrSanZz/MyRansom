// Variabel penampung data log (setelah difilter)
let currentLogs = [];

// Variabel filter
let includePattern = "";
let excludePattern = "";

// Ambil elemen-elemen
const includeInput = document.getElementById("includePattern");
const excludeInput = document.getElementById("excludePattern");
const logTableBody = document.querySelector("#logTable tbody");

const requestDetailsEl = document.getElementById("requestDetails");
const responseDetailsEl = document.getElementById("responseDetails");

// --- Event binding ---
document.getElementById("applyFilter").addEventListener("click", () => {
  includePattern = includeInput.value.trim();
  excludePattern = excludeInput.value.trim();
  fetchLogs();
});

document.getElementById("clearFilter").addEventListener("click", () => {
  includePattern = "";
  excludePattern = "";
  includeInput.value = "";
  excludeInput.value = "";
  fetchLogs();
});

document.getElementById("deleteSelected").addEventListener("click", () => {
  deleteSelectedLogs();
});

document.getElementById("clearLogs").addEventListener("click", () => {
  if (confirm("Are you sure to delete all logs?")) {
    chrome.runtime.sendMessage({ action: "clearLogs" }, (response) => {
      fetchLogs();
    });
  }
});

// --- Fungsi ambil data dari background ---
function fetchLogs() {
  chrome.runtime.sendMessage({ action: "getLogs" }, (response) => {
    if (response && response.logs) {
      // Lakukan filtering
      let logs = response.logs;

      if (includePattern) {
        logs = logs.filter(log => matchPattern(log.url, includePattern));
      }
      if (excludePattern) {
        logs = logs.filter(log => !matchPattern(log.url, excludePattern));
      }

      // Simpan ke currentLogs
      currentLogs = logs;
      renderTable(logs);
    }
  });
}

// Fungsi bantu untuk mencocokkan pattern sederhana (misal "*google*")
function matchPattern(url, pattern) {
  // Ubah pattern "*google*" menjadi regex ".*google.*"
  const regexString = pattern.replace(/\*/g, ".*");
  const regex = new RegExp(regexString, "i");
  return regex.test(url);
}

// Render tabel
function renderTable(logs) {
  logTableBody.innerHTML = "";
  logs.forEach(log => {
    const row = document.createElement("tr");

    // Checkbox
    const selectTd = document.createElement("td");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.dataset.requestId = log.requestId;
    selectTd.appendChild(checkbox);
    row.appendChild(selectTd);

    // Method
    const methodTd = document.createElement("td");
    methodTd.textContent = log.method;
    row.appendChild(methodTd);

    // URL
    const urlTd = document.createElement("td");
    urlTd.textContent = log.url;
    row.appendChild(urlTd);

    // Status
    const statusTd = document.createElement("td");
    statusTd.textContent = log.statusCode || "-";
    row.appendChild(statusTd);

    // Type
    const typeTd = document.createElement("td");
    typeTd.textContent = log.type;
    row.appendChild(typeTd);

    // IP
    const ipTd = document.createElement("td");
    ipTd.textContent = log.ip;
    row.appendChild(ipTd);

    // Time
    const timeTd = document.createElement("td");
    const date = new Date(log.timeStamp);
    timeTd.textContent = date.toLocaleTimeString() + " " + date.toLocaleDateString();
    row.appendChild(timeTd);

    // Event click row -> Tampilkan detail
    row.addEventListener("click", () => {
      showDetails(log);
    });

    logTableBody.appendChild(row);
  });
}

// Tampilkan detail request/response di panel bawah
function showDetails(log) {
  // Request Headers
  const reqHeaders = log.requestHeaders || [];
  const reqHeadersStr = reqHeaders.map(h => `${h.name}: ${h.value}`).join("\n");
  const requestInfo = `
Request ID: ${log.requestId}
Method: ${log.method}
URL: ${log.url}
Type: ${log.type}
IP: ${log.ip}

Headers:
${reqHeadersStr}

Body:
${log.requestBody || '(Empty Request Body)'}
`;

  requestDetailsEl.textContent = requestInfo;

  // Response Headers
  const resHeaders = log.responseHeaders || [];
  const resHeadersStr = resHeaders.map(h => `${h.name}: ${h.value}`).join("\n");
  const responseInfo = `
Status Code: ${log.statusCode || '-'}

Headers:
${resHeadersStr}

Body:
${log.responseBody || '(Empty Response Body)'}
`;

  responseDetailsEl.textContent = responseInfo;
}

// Hapus log terpilih
function deleteSelectedLogs() {
  const checkboxes = logTableBody.querySelectorAll("input[type='checkbox']:checked");
  const idsToDelete = Array.from(checkboxes).map(cb => cb.dataset.requestId);

  idsToDelete.forEach(requestId => {
    chrome.runtime.sendMessage({ action: "deleteLog", requestId }, () => {
      // setelah delete, refresh
      fetchLogs();
    });
  });
}

document.getElementById("sendRequest").addEventListener("click", async () => {
  const url = document.getElementById("requestUrl").value;
  const method = document.getElementById("requestMethod").value;
  const headersInput = document.getElementById("requestHeaders").value;
  const bodyInput = document.getElementById("requestBody").value;

  let headers = {};
  let body = null;

  try {
    if (headersInput) {
      headers = JSON.parse(headersInput);
    }
  } catch (error) {
    alert("Invalid JSON format in headers");
    return;
  }

  try {
    if (bodyInput && method !== "GET") {
      body = JSON.parse(bodyInput);
    }
  } catch (error) {
    alert("Invalid JSON format in body");
    return;
  }

  try {
    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null,
    });

    const result = await response.json();
    console.log("Response:", result);
    alert("Request sent successfully! Check console for response.");
  } catch (error) {
    alert("Failed to send request: " + error.message);
  }
});


// Ambil log pertama kali
fetchLogs();